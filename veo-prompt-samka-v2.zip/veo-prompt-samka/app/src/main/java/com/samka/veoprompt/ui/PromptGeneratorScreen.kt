package com.samka.veoprompt.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat.startActivity

val styleList = listOf("cinematic", "realistic", "digital painting", "vintage")
val objectList = listOf("car", "cat", "building", "robot")
val settingList = listOf("desert", "forest", "futuristic city", "underwater")
val moodList = listOf("dramatic", "serene", "mysterious", "cheerful")
val colorList = listOf("warm", "cool", "pastel", "neon")

@Composable
fun PromptGeneratorScreen() {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var style by remember { mutableStateOf("") }
    var obj by remember { mutableStateOf("") }
    var setting by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(listOf<String>()) }

    val prompt = "A $style $obj in $setting with $mood mood and $color color scheme."

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Veo Prompt Generator", fontSize = 20.sp)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(value = style, onValueChange = { style = it }, label = { Text("Style") })
        OutlinedTextField(value = obj, onValueChange = { obj = it }, label = { Text("Object") })
        OutlinedTextField(value = setting, onValueChange = { setting = it }, label = { Text("Setting") })
        OutlinedTextField(value = mood, onValueChange = { mood = it }, label = { Text("Mood") })
        OutlinedTextField(value = color, onValueChange = { color = it }, label = { Text("Color") })

        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            style = styleList.random()
            obj = objectList.random()
            setting = settingList.random()
            mood = moodList.random()
            color = colorList.random()
        }) {
            Text("Random Prompt")
        }

        Spacer(Modifier.height(8.dp))

        Text("Prompt:", fontSize = 16.sp)
        Text(prompt, fontSize = 14.sp)

        Spacer(Modifier.height(8.dp))

        Row {
            Button(onClick = {
                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(prompt))
                Toast.makeText(context, "Prompt copied!", Toast.LENGTH_SHORT).show()
            }) {
                Text("Copy")
            }

            Spacer(Modifier.width(8.dp))

            Button(onClick = {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, prompt)
                    type = "text/plain"
                }
                val shareIntent = Intent.createChooser(sendIntent, null)
                startActivity(context, shareIntent, null)
            }) {
                Text("Share")
            }

            Spacer(Modifier.width(8.dp))

            Button(onClick = {
                favorites = favorites + prompt
                Toast.makeText(context, "Added to favorites", Toast.LENGTH_SHORT).show()
            }) {
                Text("Favorite")
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Favorites:", fontSize = 16.sp)
        LazyColumn {
            items(favorites) {
                Text("• $it", fontSize = 12.sp)
            }
        }
    }
}
