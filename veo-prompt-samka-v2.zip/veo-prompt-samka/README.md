# Veo Prompt SAMKA

Aplikasi Android untuk menghasilkan prompt otomatis untuk Veo V3 SAMKA.